package edu.westga.cs1301.project1.controller;

import edu.westga.cs1301.project1.model.ProductLabel;
import edu.westga.cs1301.project1.model.StoreInventory;

/** Uses the ProductLabel and StoreInventory classes to demonstrate the system's intended functionality
 * 
 * @author CS 1301
 * @version Summer 2022
 */
public class DemonstrationController {
	
	private void generateProductLabels() {
		//TODO Part 1 - generate and print a label for Monopoly (Monopoly, $12.34)
		ProductLabel newLabel = new ProductLabel("Monopoly", 12.34);
        String getProductLabel = newLabel.getProductLabel();
        System.out.println(getProductLabel);
         
		//TODO Part 1 - generate and print a label for Table (Small Table, $56.78)
         ProductLabel newLabel1 = new ProductLabel("Small Table", 56.78);
         String getProductLabel1 = newLabel1.getProductLabel();
         System.out.println(getProductLabel1);
	}
	
	private void generateStoreInventories() {
		//TODO Part 2 - generate and print inventory text for Monopoly Store (Monopoly Store, Monopoly, $12.34, 3)
		ProductLabel productLabel = new ProductLabel("Monopoly", 12.34);
		StoreInventory newInventory = new StoreInventory("Monopoly Store",productLabel,3);	      
	        String getStoreInventories = newInventory.getStoreInventories();
	        System.out.println(getStoreInventories);
	        
	
	
 
		//TODO Part 2 - generate and print inventory text for Blanket Store (Blanket Store, Comfy Blanket, $56.78, 0)
	    ProductLabel newLabel1 = new ProductLabel("Small Table", 56.78);
	    StoreInventory newInventory1 = new StoreInventory("Blanket Store",newLabel1,0);     
	    String getStoreInventories1 = newInventory1.getStoreInventories();
        System.out.println(getStoreInventories1); 
            
	}
	
	private void generateMultipleStores(int storeCount, String storeName, String productName, double productPrice, int quantity) {
		//TODO - Part 3
		
	}
	
	/** Demonstrates the functionality of the system.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void run() {
		System.out.println("Demonstrating Generating Product Labels");
		this.generateProductLabels();
		System.out.println("Demonstrating Generating Store Inventories");
		this.generateStoreInventories();
		System.out.println("Demonstrating Generating Multiple Stores");
		this.generateMultipleStores(3, "Monopoly Store", "Monopoly", 12.34, 3);
		this.generateMultipleStores(0, "Blanket Store", "Comfy Blanket", 56.78, 0);
	}

}
