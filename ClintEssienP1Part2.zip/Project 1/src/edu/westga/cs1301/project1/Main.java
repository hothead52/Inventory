package edu.westga.cs1301.project1;

import edu.westga.cs1301.project1.controller.DemonstrationController;

/** Entry point for the application.
 * 
 * @author CS 1301
 * @version Summer 2022
 */
public class Main {

	/** Entry point for the program: creates the GUI object and calls its start
	 * method, which in turn calls its init and run methods.
	 *
	 * @precondition none
	 * @postcondition the system functionality has been demonstrated
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		DemonstrationController demonstrationController = new DemonstrationController();
		demonstrationController.run();
	}

}
