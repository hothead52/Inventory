package edu.westga.cs1301.project1.model;

/** Stores and manages the information for a street label.
 * 
 * @author CS 1301
 * @version Summer 2022
 */
public class StoreInventory {
	//TODO Part 2
    private String storeName;
    private int quantity;
    private ProductLabel productLabel;
   

    public StoreInventory(String storeName,ProductLabel productLabel,int quantity ) {
    	this.storeName = storeName;
    	this.quantity = quantity;
    	this.productLabel = productLabel;
    	
    }
    public String getStoreName() {
		return this.storeName;
    	
    }
    public int getQuantity() {
		return this.quantity;
    	
    }
    public ProductLabel getProductLabel() {
		return this.productLabel;
    }
    
    /**
	 * Returns the store inventory format
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return "<store name>"
			+ "#1<product name> - $< product price>"
			+ "#2<product name> - $< product price>"
			+ "#<quantity> <product name> - $<product price>"
	 */
 public String getStoreInventories() {
	String inventoryText = this.storeName+""+ System.lineSeparator();
	inventoryText +=this.getQuantity()+""+this.getProductLabel()+""+ System.lineSeparator();
	for (int i = 0; i < this.getQuantity(); i++) {

		
		}
	return inventoryText ;
		
 }
 
}
 
 

			
			