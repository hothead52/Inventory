package edu.westga.cs1301.project1.model;

/** Stores and manages the information for a house label.
 * 
 * @author CS 1301
 * @version Summer 2022
 */
public class ProductLabel {
	//TODO Part 1
	 private String name;
	 private double price;
	 
	 /**
		 * Creates and initializes the price and name for a house label.
		 * 
		 * @precondition none
		 * @postcondition none
		 * 
		 */
	 public ProductLabel(String name, double price) {
		 this.name = name;
		 this.price = price;
	 }
	 /**
		 * Returns the price of the Product
		 * 
		 * @precondition none
		 * @postcondition none
		 * 
		 * @return price
		 */
	 public double getPrice() {
		return this.price;
		 
	 }
	 /**
		 * Returns the price of the Product
		 * 
		 * @precondition none
		 * @postcondition none
		 * 
		 * @return productName
		 */
	 public String getName() {
		return this.name;
		 
	 }
	 /**
		 * Returns the product label format
		 * 
		 * @precondition none
		 * @postcondition none
		 * 
		 * @return "name-$price"
		 */
	 public String getProductLabel() {
		return (this.name + " - $" + this.price);
		
		 
	 }
}
